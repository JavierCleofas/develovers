# Changelog

    1.0.6
    # Fixed template widgets media 'auto' settings

    1.0.5
    # Fixed navbar and block padding behavior
    # Fixed push footer to page bottom

    1.0.4
    # Fixed theme specific overlay .tm-overlay-lykka
    # Fixed socialbuttons

    1.0.3
    # Fixed menu items overlapping logo

    1.0.2
    + Added widgetkit folder to templateDetails.xml

    1.0.1
    # Prevent fixed navbar from overlaying toolbar

    1.0.0
    + Initial Release



    * -> Security Fix
    # -> Bug Fix
    $ -> Language fix or change
    + -> Addition
    ^ -> Change
    - -> Removed
    ! -> Note
